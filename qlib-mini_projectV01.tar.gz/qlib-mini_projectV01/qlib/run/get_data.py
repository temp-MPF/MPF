#  Copyright (c) Microsoft Corporation.
#  Licensed under the MIT License.

import fire
from qlib.tests.data import GetData


if __name__ == "__main__":
    fire.Fire(GetData)
