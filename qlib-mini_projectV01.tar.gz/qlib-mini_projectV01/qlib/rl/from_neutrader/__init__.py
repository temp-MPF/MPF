# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

# TODO: find a better way to organize contents under this module.
